package dreamteam.iam.cat.autoterminalemployee;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class ConexioServerURL extends Thread {

    URLConnection connection;
    Context context;
    String data;
    OutputStreamWriter out;
    BufferedReader in;

    public ConexioServerURL(Context context, String data) {
        this.context = context;
        this.data = data;
    }

    @Override
    public void run() {
        //Looper.prepare();
        try {
            connection = new URL(Constants.URL).openConnection();
            connection.setDoOutput(true);

            switch (context.getClass().getSimpleName().toString()) {
                case Constants.CONTEXT_LOCALITZAR_VEHICLE:
                    out = new OutputStreamWriter(connection.getOutputStream());
                    out.write(Constants.PETICIO_ON_ES_EL_VEHICLE + data);
                    out.close();
                    in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    LocalitzarVehicle.xml = in.readLine();
                    Log.d("hola" , LocalitzarVehicle.xml);
                    in.close();
                    break;
                case Constants.CONTEXT_INGRESSAR_VECHICLE:
                    out = new OutputStreamWriter(connection.getOutputStream());
                    out.write(Constants.PETICIO_EMPARELLAR_VEHICLE + data);
                    out.close();
                    in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    IngressarVehicle.estat = in.readLine();
                    Log.d("hola" , IngressarVehicle.estat);
                    in.close();
                    break;
                case Constants.CONTEXT_BAIXA_VECHICLE:
                    out = new OutputStreamWriter(connection.getOutputStream());
                    out.write(Constants.PETICIO_BAIXA_VEHICLE + data);
                    out.close();
                    in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    BaixaVehicle.estat = in.readLine();
                    Log.d("hola" , BaixaVehicle.estat);
                    in.close();
                    break;
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

