package dreamteam.iam.cat.autoterminalemployee;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;

public class LocalitzarVehicle extends AppCompatActivity {

    public static EditText resultatCodi;
    public static String xml;
    public static double coordX = 4.2;
    public static double coordY = 3.9;
    public static String placa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_localitzar_vehicle);

        resultatCodi = (EditText) findViewById(R.id.eTBastidor);

        if(resultatCodi.getText().toString().equals("")) {
            Toast.makeText(this, getResources().getString(R.string.PutNumber), Toast.LENGTH_LONG).show();
        }
    }

    public void onClickMapa(View view) {
        Intent intent = new Intent(this, Mapa.class);

        startActivity(intent);
    }

    public void onClickFoto(View view) {
        Intent intent = new Intent(this, ScanCode.class);
        intent.putExtra("PreviaActivitat", "LocV");
        startActivity(intent);

    }

    public void onClickBuscar(View view) {

        //enviar a servidor 401 | numbastidor
        /*ConexioServerURL conexio = new ConexioServerURL(this, resultatCodi.getText().toString());
        conexio.start();
        try {
            conexio.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/

        if(resultatCodi.getText().toString().equals("")) {
            Toast.makeText(this, getResources().getString(R.string.PutNumber), Toast.LENGTH_LONG).show();
        }else {
            EditText etBastidor = (EditText) findViewById(R.id.eTBastidor2);
            EditText etColor = (EditText) findViewById(R.id.eTColor);
            EditText etModel = (EditText) findViewById(R.id.eTModel);
            EditText etMarca = (EditText) findViewById(R.id.eTMarca);
            EditText etCaract = (EditText) findViewById(R.id.eTCaract);
            EditText etPlaca = (EditText) findViewById(R.id.eTPlaca);
            EditText etPlanta = (EditText) findViewById(R.id.eTPlanta);
            EditText etEdifici = (EditText) findViewById(R.id.eTEdifici);
            EditText etDataEntrada = (EditText) findViewById(R.id.eTDataEntrada);
            EditText etDataSortida = (EditText) findViewById(R.id.eTDataSortida);

            Vehicle vehicleTrobat = new Vehicle();

            try {
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();
                xpp.setInput(new StringReader("<vehicle><bastidor>numbastidor</bastidor><color>vermell</color><model>ibiza</model><marca>seat</marca><caract>gps</caract><placa>44</placa><planta>planta 0</planta><edifici>edifici 0</edifici><dataentrada>10102018</dataentrada><datasortida>11112018</datasortida></vehicle>"));
                //xpp.setInput(new StringReader(xml);
                while (xpp.next() != XmlPullParser.END_DOCUMENT) {
                    int event = xpp.getEventType();
                    switch (event) {
                        case XmlPullParser.START_TAG:
                            String nomEti = xpp.getName();
                            if (nomEti.equals("bastidor")) {
                                xpp.next();
                                vehicleTrobat.setBastidor(xpp.getText());
                            } else if (nomEti.equals("color")) {
                                xpp.next();
                                vehicleTrobat.setColor(xpp.getText());
                            } else if (nomEti.equals("model")) {
                                xpp.next();
                                vehicleTrobat.setModel(xpp.getText());
                            } else if (nomEti.equals("marca")) {
                                xpp.next();
                                vehicleTrobat.setMarca(xpp.getText());
                            } else if (nomEti.equals("caract")) {
                                xpp.next();
                                vehicleTrobat.setCaracteristiques(xpp.getText());
                            } else if (nomEti.equals("placa")) {
                                xpp.next();
                                vehicleTrobat.setPlaca(xpp.getText());
                                placa = xpp.getText();
                            } else if (nomEti.equals("planta")) {
                                xpp.next();
                                vehicleTrobat.setPlanta(xpp.getText());
                            } else if (nomEti.equals("edifici")) {
                                xpp.next();
                                vehicleTrobat.setEdifici(xpp.getText());
                            } else if (nomEti.equals("dataentrada")) {
                                xpp.next();
                                vehicleTrobat.setDataIngres(xpp.getText());
                            } else if (nomEti.equals("datasortida")) {
                                xpp.next();
                                vehicleTrobat.setDataSortida(xpp.getText());
                            }
                            break;
                    }

                }

            } catch (XmlPullParserException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            etBastidor.setText(resultatCodi.getText());
            //etBastidor.setText(vehicleTrobat.getBastidor());
            etColor.setText(vehicleTrobat.getColor());
            etModel.setText(vehicleTrobat.getModel());
            etMarca.setText(vehicleTrobat.getMarca());
            etCaract.setText(vehicleTrobat.getCaracteristiques());
            etPlaca.setText(vehicleTrobat.getPlaca());
            etPlanta.setText(vehicleTrobat.getPlanta());
            etEdifici.setText(vehicleTrobat.getEdifici());
            etDataEntrada.setText(vehicleTrobat.getDataIngres());
            etDataSortida.setText(vehicleTrobat.getDataSortida());
        }
    }
}
