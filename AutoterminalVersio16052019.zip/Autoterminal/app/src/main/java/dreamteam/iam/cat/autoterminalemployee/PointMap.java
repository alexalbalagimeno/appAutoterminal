package dreamteam.iam.cat.autoterminalemployee;

public class PointMap {

    double x;
    double y;
    int numColumnes = 7;
    int numFiles = 6;

    public PointMap(double x, double y) {
        super();
        this.x = x;
        this.y = y;
    }

    public double calculaDistanciaAltrePunt(PointMap otherPointMap) {
        return (Math.sqrt(Math.pow(x - otherPointMap.x, 2) + Math.pow(y - otherPointMap.y, 2)));
    }

    public String comunicaCela() {
        for (int columna = 0; columna < numColumnes; columna++) {
            for (int fila = 0; fila < numFiles; fila++) {
                if (x == (columna + 0.5) && y == (fila + 0.5)) {
                    return "F" + (fila + 1) + "C" + (columna + 1);
                }
            }
        }
        return "null";
    }
}


