package dreamteam.iam.cat.autoterminalemployee;

public class Usuari {

    String nom;
    String contra;

    public Usuari(String nom, String contra) {
        this.nom = nom;
        this.contra = contra;
    }

    public String getNom() {
        return nom;
    }

    public String getContra() {
        return contra;
    }
}
