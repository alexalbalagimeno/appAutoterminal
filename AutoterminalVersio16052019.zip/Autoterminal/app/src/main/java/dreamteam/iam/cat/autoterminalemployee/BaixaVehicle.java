package dreamteam.iam.cat.autoterminalemployee;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class BaixaVehicle extends AppCompatActivity {

    public static EditText resultatCodiVehicle;
    public static String estat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baixa_vehicle);

        resultatCodiVehicle = (EditText)findViewById(R.id.eTIngressarVehicle);

        if(resultatCodiVehicle.getText().toString().equals("")) {
            Toast.makeText(this, getResources().getString(R.string.PutNumber), Toast.LENGTH_LONG).show();
        }

    }

    public void onClickBotoFotoBaixaVehicle(View view) {
        Intent intent = new Intent(this,ScanCode.class);
        intent.putExtra("PreviaActivitat", "BaixaV");
        startActivity(intent);
    }

    public void onClickBotoConfirmarBaixa(View view) {

        if(resultatCodiVehicle.getText().toString().equals("")) {
            Toast.makeText(this, getResources().getString(R.string.PutNumber), Toast.LENGTH_LONG).show();
        }
        else {
            /*ConexioServerURL conexio = new ConexioServerURL(this, resultatCodiVehicle.getText().toString());
            conexio.start();
            try {
                conexio.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (estat.equals("true"))
                Toast.makeText(this, getResources().getString(R.string.DeletedCar), Toast.LENGTH_LONG).show();
            else
                Toast.makeText(this, getResources().getString(R.string.UpdateFailed), Toast.LENGTH_LONG).show();*/
            Toast.makeText(this,"Codi erroni", Toast.LENGTH_LONG).show();
        }
    }

}
