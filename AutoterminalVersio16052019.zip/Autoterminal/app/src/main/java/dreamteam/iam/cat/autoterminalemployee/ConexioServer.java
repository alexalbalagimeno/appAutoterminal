package dreamteam.iam.cat.autoterminalemployee;

import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class ConexioServer extends Thread{

    Socket socket = null;
    PrintWriter out = null;
    BufferedReader in = null;
    static String hostName = "192.168.204.102";
    static int portNumber = 1234;
    Context context;
    String data;

    public ConexioServer(Context context, String data){
        this.context = context;
        this.data = data;
    }
    @Override
    public void run() {
        //Looper.prepare();
        try {
            socket = new Socket(hostName, portNumber);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            if(context.getClass().getSimpleName().toString().equals(Constants.CONTEXT_LOCALITZAR_VEHICLE)) {
                out.println(Constants.PETICIO_ON_ES_EL_VEHICLE + "|" + data);
                LocalitzarVehicle.xml = in.readLine();
            }
            else if(context.getClass().getSimpleName().toString().equals(Constants.CONTEXT_INGRESSAR_VECHICLE)) {
                out.println(Constants.PETICIO_EMPARELLAR_VEHICLE + "|" + data);
                IngressarVehicle.estat = in.readLine();
            }
            else if(context.getClass().getSimpleName().toString().equals(Constants.CONTEXT_BAIXA_VECHICLE)){
                out.println(Constants.PETICIO_BAIXA_VEHICLE + "|" + data);
                BaixaVehicle.estat = in.readLine();
            }
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host " + hostName);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " + hostName);
        } finally {
            try {
                in.close();
                out.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
