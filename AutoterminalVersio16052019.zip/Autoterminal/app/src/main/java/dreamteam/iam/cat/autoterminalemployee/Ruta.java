package dreamteam.iam.cat.autoterminalemployee;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Ruta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruta);
    }
}
