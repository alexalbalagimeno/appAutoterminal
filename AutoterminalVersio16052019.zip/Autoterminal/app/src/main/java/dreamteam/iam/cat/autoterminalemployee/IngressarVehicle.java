package dreamteam.iam.cat.autoterminalemployee;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class IngressarVehicle extends AppCompatActivity {

    public static EditText resultatCodiVehicle;
    public static EditText resultatCodiDispositiu;
    public static String estat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingressar_vehicle);

        resultatCodiVehicle = (EditText)findViewById(R.id.eTIngressarVehicle);
        resultatCodiDispositiu = (EditText)findViewById(R.id.eTIngressarDispositiu);

        if(resultatCodiVehicle.getText().toString().equals("") || resultatCodiDispositiu.getText().toString().equals("")) {
            Toast.makeText(this, getResources().getString(R.string.PutNumber), Toast.LENGTH_LONG).show();
        }
    }

    public void onClickBotoFotoIngressarVehicle(View view) {
        Intent intent = new Intent(this,ScanCode.class);
        intent.putExtra("PreviaActivitat", "IngV");
        startActivity(intent);
    }

    public void onClickBotoFotoIngressarDispositiu(View view) {
        Intent intent = new Intent(this,ScanCode.class);
        intent.putExtra("PreviaActivitat", "IngD");
        startActivity(intent);
    }

    public void onClickBotoConfirmarIngressar(View view) {
        if(resultatCodiVehicle.getText().toString().equals("") || resultatCodiDispositiu.getText().toString().equals("")) {
            Toast.makeText(this, getResources().getString(R.string.PutNumber), Toast.LENGTH_LONG).show();
        }
        else{
            /*ConexioServerURL conexio = new ConexioServerURL(this, resultatCodiVehicle.getText().toString()+"|"+resultatCodiDispositiu.getText());
            conexio.start();
            try {
                conexio.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if(estat.equals("true"))
                Toast.makeText(this, getResources().getString(R.string.AddedCar), Toast.LENGTH_LONG).show();
            else
                Toast.makeText(this, getResources().getString(R.string.UpdateFailed), Toast.LENGTH_LONG).show();*/
            Toast.makeText(this,"Codi erroni", Toast.LENGTH_LONG).show();
        }
    }


}
