package dreamteam.iam.cat.autoterminalemployee;

import android.widget.EditText;

public class Vehicle {

    String Bastidor;
    String Color;
    String Model;
    String Marca;
    String Caracteristiques;
    String Placa;
    String Planta;
    String Edifici;
    String DataIngres;
    String DataSortida;

    public Vehicle() {
    }

    public Vehicle(String bastidor, String color, String model, String marca, String caracteristiques, String placa, String planta, String edifici, String dataIngres, String dataSortida) {
        this.Bastidor = bastidor;
        this.Color = color;
        this.Model = model;
        this.Marca = marca;
        this.Caracteristiques = caracteristiques;
        this.Placa = placa;
        this.Planta = planta;
        this.Edifici = edifici;
        this.DataIngres = dataIngres;
        this.DataSortida = dataSortida;
    }

    public String getBastidor() {
        return Bastidor;
    }

    public void setBastidor(String bastidor) {
        Bastidor = bastidor;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        Color = color;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String marca) {
        Marca = marca;
    }

    public String getCaracteristiques() {
        return Caracteristiques;
    }

    public void setCaracteristiques(String caracteristiques) {
        Caracteristiques = caracteristiques;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String placa) {
        Placa = placa;
    }

    public String getPlanta() {
        return Planta;
    }

    public void setPlanta(String planta) {
        Planta = planta;
    }

    public String getEdifici() {
        return Edifici;
    }

    public void setEdifici(String edifici) {
        Edifici = edifici;
    }

    public String getDataIngres() {
        return DataIngres;
    }

    public void setDataIngres(String dataIngres) {
        DataIngres = dataIngres;
    }

    public String getDataSortida() {
        return DataSortida;
    }

    public void setDataSortida(String dataSortida) {
        DataSortida = dataSortida;
    }
}
