package dreamteam.iam.cat.autoterminalemployee;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MenuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);
    }
    public void onClickBotoIngressarVehicle(View view) {
        Intent intent = new Intent(this,IngressarVehicle.class);
        startActivity(intent);
    }
    public void onClickBotoBaixaVehicle(View view) {
        Intent intent = new Intent(this,BaixaVehicle.class);
        startActivity(intent);
    }
    public void onClickBotoLocalitzarVehicle(View view) {
        Intent intent = new Intent(this,LocalitzarVehicle.class);
        startActivity(intent);
    }
    public void onClickBotoReportarIncidencia(View view) {
        Intent intent = new Intent(this,MenuPrincipal.class);
        startActivity(intent);
    }
}
